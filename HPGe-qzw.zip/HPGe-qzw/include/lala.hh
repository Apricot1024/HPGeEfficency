#define lala_R 5.00

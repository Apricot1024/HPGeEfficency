#! /bin/zsh
for ((i=10; i<=1000; i+=10)); do
    cp -R B1/ ${i}egr
done
echo 'succeed 2'